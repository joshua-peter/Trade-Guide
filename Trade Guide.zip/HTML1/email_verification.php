<?php
include("connection.php");
error_reporting(0);
date_default_timezone_set("Asia/Hyderabad");

if(!empty($_GET['code']) && isset($_GET['code']))
{
    $code=$_GET['code'];
    $sql=mysqli_query($conn,"SELECT * FROM signup WHERE 
    vcode='$code'");
    $num=mysqli_num_rows($sql);
    if($num>0)
    {
        $st=0;
        $result= mysqli_query($conn,"select * from signup where 
        vcode='$code' and status='0'");
        $result4=mysqli_fetch_array($result);

        if($result4>0)
        {
            $st=1;
            $result1=mysqli_query($conn,"UPDATE signup SET status='$st' WHERE vcode='$code'");
            $msg="Your account is activated<br>";
            echo "EMAIL VERIFICATION<br>";
            echo $msg;
            echo "You can login now<br>";
        }
        else{
            $msg="Your account is already active<br>";
            echo "EMAIL VERIFICATION<br>";
            echo $msg;
            echo "You can login now<br>";
        }
    }
    else
    {
        $msg="Ivalid verification code";
        echo $msg;
    }
}
else
{
    echo "Code not set";
}