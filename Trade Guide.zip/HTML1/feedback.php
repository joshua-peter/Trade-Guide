<?php
session_start();
include("connection.php");
error_reporting(0);
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
    <head>
        <meta charset="UTF-8">
        <script>
            function login(){
                window.location = 'login1.php';
            }
        </script>
        <title>
            Feedback Form
        </title>
        <style>
            BODY{
                margin: 0;
                padding: 0;
                font-family: sans-serif; 
            }
            *{
                box-sizing: border-box; 
            }
            .header{
    min-height: 100vh;
    width:100%;
    background-image: url("feedback.jpg");
    background-position:center;
    background-size:cover;
    position: relatsive; 
}

            .container{
                width: 600px;
                padding: 40px;
                position: absolute;
                top: 50%;
                left: 50%;
                transform: translate(-50%,-50%);
                text-align: center;
                border-style: solid;
                color:white;
    text-transform: uppercase;
    font-weight: 200;
            }
            input[type=text],input[type=email],input[type=password]{
                border: 0;
                color: white;
                background: none;
                display: block;
                text-transform: uppercase;
                margin: 20px auto;
                text-align: center;
                border: 2px solid #fff3f3;
                padding: 14px 10px;
                width: 400px;
                outline: none;
                border-radius: 24px;
                transition: 0.25px;
            }
            input[type=text]:focus,input[type=email]:focus,input[type=password]:focus{
                width: 280px;
                border-color: #2ecc71;
                color:white;
            }
            .registerbtn{
                border: 0;
                background: none;
                display: block;
                margin: 20px auto;
                text-align: center;
                border: 2px solid rgb(24, 211, 33);
                padding: 14px 40px;
                outline: none;
                color: white;
                border-radius: 24px;
                transition: 0.25px;
                cursor: pointer;
            }
            .registerbtn:hover{
                background: rgb(24, 211, 33);
            }
            #button
            {
                border: 0;
                background: none;
                display: block;
                margin: 20px auto;
                text-align: center;
                border: 2px solid rgb(24, 211, 33);
                padding: 14px 40px;
                outline: none;
                color: white;
                border-radius: 24px;
                transition: 0.25px;
                cursor: pointer;
            }
            a{
                color: blue;
            }
            .login{
                background: whitesmoke;
                text-align: centre;
            }
        </style>
    </head>
    <body>
    <section class="header">
    <div class="container">
        <form class="box" action="" method="post">
        <form class="box" action="feedback.php" method="post">
                <h1>Feedback Form</h1>
            <input type="text" id="name" placeholder="Name" name="name"required>
            <input type="text" id="query" placeholder="Any Queries?" name="query"required>
            <input type="text" id="helpful" placeholder="Was this information helpful?" name="helpful"required>
            <input type="text" id="suggest" placeholder="Any Suggestions?" name="suggest"required>
             <tr>
                 <td><input type="submit" id="button" name="submit"></td>
             </tr>
             <button class="registerbtn" onclick="login()">Logout</button>
            </form>
        </form>
    </div>
       </section>
    </body>
</html>

<?php
date_default_timezone_set("Asia/Hyderabad");
if(isset($_POST['submit']))
{
$nm=$_POST['name'];
$qu=$_POST['query'];
$help=$_POST['helpful'];
$sugg=$_POST['suggest'];
if($nm!="" &&  $qu!="" && $sugg!="" && $help!="")
{
//echo "$nm";
//echo "$em";
//echo "$psw";
//echo "$rpsw";
    $query1 = "select * from feedback where email='$em'";
    $data1 = mysqli_query($conn,$query1);
    $total= mysqli_num_rows($data1);
    $email = $_SESSION['uemail'];
    if($total)
    {
        echo '<script>alert("Email already exists")</script>';
    }
    else
    {
        $query="INSERT INTO FEEDBACK VALUES ('$nm','$email','$qu','$help','$sugg')";
        $data=mysqli_query($conn,$query);
        if($data)
        {
            echo '<script>alert("Feedback Sent Successsfully")</script>';
        }
        else{
            echo '<script>alert("Feedback Not Sent")</script>';
        }
    }
}
else{
   echo '<script>alert("Please fill all the fields")</script>';
}
}
?>