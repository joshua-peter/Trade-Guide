<?php
session_start();
include("connection.php");
error_reporting(0);
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <style>
            BODY{
                margin: 0;
                padding: 0;
                font-family: sans-serif; 
            }
            *{
                box-sizing: border-box; 
            }
            .container{
                width: 600px;
                padding: 40px;
                position: absolute;
                top: 10%;
                left: 50%;
                transform: translate(-50%,0%);
                border-style: solid;
                text-align: center;
                color:white;
    text-transform: uppercase;
    font-weight: 200;
            }
            input[type=email],input[type=password]{
                border: 0;
                background: none;
                display: block;
                margin: 20px auto;
                text-align: center;
                border: 2px solid #fff3f3;
                padding: 14px 10px;
                width: 200px;
                outline: none;
                color: white;
                border-radius: 24px;
                transition: 0.25px;
            }
            .header{
    min-height: 100vh;
    width:100%;
    background-image: url("crypto3.jpg");
    background-position:center;
    background-size:cover;
    position: relatsive; 
}
            input[type=email]:focus,input[type=password]:focus{
                width: 280px;
                border-color: #2ecc71;
            }
            .registerbtn{
                border: 0;
                background: none;
                display: block;
                margin: 20px auto;
                text-align: center;
                border: 2px solid #ffc400ec;
                padding: 14px 40px;
                outline: none;
                color: white;
                border-radius: 24px;
                transition: 0.25px;
                cursor: pointer;
            }
            .registerbtn:hover{
                background: #ffc400ec;
            }
            #button
            {
                border: 0;
                background: none;
                display: block;
                margin: 20px auto;
                text-align: center;
                border: 2px solid #ffc400ec;
                padding: 14px 40px;
                outline: none;
                color: white;
                border-radius: 24px;
                transition: 0.25px;
                cursor: pointer;
            }
            a{
                color: blue;
            }
            .login{
                background: whitesmoke;
                text-align: centre;
            }
        </style>
</head>
<body>
<section class="header">
<div class="container">
        <form class="box" action="" method="post">
        <form class="box" action="signup1.php" method="post">
            <h1>LOGIN</h1>
            <p>Enter your details</p>
            <input type="email" id="email" placeholder="Email" name="email" required>
            <input type="password" id="psw" placeholder="Password" name="password" required>
             <tr>
                 <td><input type="submit" id="button" name="submit"></td>
             </tr>
            </form>
        </form>
       </div>
        </section>
    </body>
</html>

<?php
if(isset($_POST['submit']))
{
    $em=$_POST['email'];
    $_SESSION['uemail'] = $em;
    $psw=$_POST['password'];
    $query = "select * from signup where email='$em'";
    $data = mysqli_query($conn,$query);
    $total= mysqli_num_rows($data);
    $result= mysqli_fetch_assoc($data);
    if($total)
    {
        $ciphering= "AES-128-CTR";
        $st=1;
        $option=0;
        $decription_iv= '12345678901234567';
        $decription_key= "joshuakanishkacharan";
        //echo $result['name'];
        if(openssl_decrypt($result['password'],$ciphering,$decription_key,$option,$decription_iv)==$psw)
        {
            if($result['status']==$st)
            {
            $_SESSION['email']=$_POST['email'];
           header('Location: /HTML1/trade guide/Index.html');
           exit;
            }
            else{
                echo '<script>alert("Please verify your email")</script>';
            }
        }
        else{
            echo '<script>alert("Invalid Password")</script>';
        }
    }
    else{
        echo '<script>alert("Invalid Email ID")</script>';
    }
}
?>